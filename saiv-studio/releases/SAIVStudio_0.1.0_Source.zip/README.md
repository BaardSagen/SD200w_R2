# SAIV Instrument Studio 0.1.0

Første selvstendige Windows-utgave i C++ / Dear ImGui / DirectX 11. Dette er et nytt program med egen kode. Det laster ikke Delphi-programmet. Ikonet er brukerens `icon/ctd_in_Cage.ico`.

## Start

Kjør `SAIVStudio.exe` fra den portable pakken. Velg **Try demonstration** for syntetiske data uten instrument. Åpne virkelige målefiler med **Open data file**. Ingen port åpnes automatisk ved vanlig oppstart.

- Overview viser siste måleverdier og kurve.
- Terminal viser RX/TX, lagrer terminaltekst og mottatte data, og har Wake/menu og Download.
- Data & profiles viser grafer, tabell, kanaloversikt, statistikk og CSV-eksport.
- Utilities lager nye datasett for beregning, splitting, filtrering, spike-fjerning, gain/offset og standardnivåer.
- Logger files leser og kopierer filer fra montert loggerdisk uten å slette eller overskrive eksisterende filer.

Se [funksjonsstatus](docs/FUNKSJONSSTATUS.md), [kommunikasjon](docs/KOMMUNIKASJON.md) og [kildegrunnlag](docs/KILDEGRUNNLAG.md). Full funksjonslikhet med det gamle programmet er **ikke** ferdig. Fysisk akseptansetest gjenstår.

## Bygg og viderefør på annen PC

Kildepakken inkluderer `src`, `assets`, tester, eksempelfiler og vendorkilde. Installer Visual Studio med Desktop development with C++, Windows SDK, CMake og Ninja. Kjør `build.cmd` fra kildekatalogen. Skriptet finner Visual Studio via vswhere, bygger Release x64 med statisk C++ runtime og kjører CTest. Sluttfil: `build/SAIVStudio.exe`.

```powershell
.\build.cmd
cmake --install build --prefix dist/SAIVStudio-0.1.0
```

Ingen nettverksnedlasting er nødvendig fra komplett kildepakke. `tests/gui_smoke.py` krever Python og Pillow og starter en egen demo-instans. Den tester navigasjon og skjermbilder med faktiske museklikk. Ikke kjør den mens du bruker musen til annet arbeid. Kjerne-/protokolltester bruker ingen instrumenter.

Windows x64 og DirectX 11 kreves. Windows-fontene Segoe UI/Consolas brukes når de finnes, med fallback. Innstillinger lagres under `%LOCALAPPDATA%/SAIV/InstrumentStudio/settings.txt`. Ingen server, konto eller installasjonstjeneste brukes.

Always keep backup copies of your data files and verify measurement results before relying on them.

Se [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) og medfølgende lisenser. Denne lokale utgaven er ikke publisert til GitHub.
