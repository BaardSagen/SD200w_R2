import subprocess,time,ctypes as c,json,hashlib,sys
from ctypes import wintypes as w
from pathlib import Path
from PIL import ImageGrab
root=Path(__file__).resolve().parents[1];out=root/'test-results';out.mkdir(exist_ok=True)
u=c.WinDLL('user32');u.GetWindowThreadProcessId.argtypes=[w.HWND,c.POINTER(w.DWORD)];u.GetWindowRect.argtypes=[w.HWND,c.POINTER(w.RECT)];u.SetForegroundWindow.argtypes=[w.HWND];u.PostMessageW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM]
CB=c.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM);u.EnumWindows.argtypes=[CB,w.LPARAM]
exe=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root/'build/SAIVStudio.exe'
p=subprocess.Popen([str(exe),'--demo'],cwd=out)
try:
 time.sleep(3);found=[]
 @CB
 def enum(h,l):
  pid=w.DWORD();u.GetWindowThreadProcessId(h,c.byref(pid))
  if pid.value==p.pid:found.append(h)
  return True
 u.EnumWindows(enum,0);assert found
 u.IsWindowVisible.argtypes=[w.HWND];found=[h for h in found if u.IsWindowVisible(h)]
 u.ClientToScreen.argtypes=[w.HWND,c.POINTER(w.POINT)]
 hashes=[]
 h=found[0];u.SetForegroundWindow(h);time.sleep(.5);r=w.RECT();u.GetWindowRect(h,c.byref(r))
 for i,name in enumerate(['overview','terminal','data','utilities','logger','about']):
  # App navigation uses consistent 41 px rows below the SAIV heading.
  y=120+37*i
  pt=w.POINT(80,y);u.ClientToScreen(h,c.byref(pt));u.SetCursorPos(pt.x,pt.y);time.sleep(.1);u.mouse_event(2,0,0,0,0);time.sleep(.1);u.mouse_event(4,0,0,0,0);time.sleep(.5)
  capture=ImageGrab.grab(bbox=(r.left,r.top,r.right,r.bottom));capture.save(out/(name+'.png'));hashes.append(hashlib.sha256(capture.crop((260,100,1200,750)).tobytes()).hexdigest())
 assert len(set(hashes))==6,hashes
 assert p.poll() is None
 u.PostMessageW(h,0x10,0,0);assert p.wait(timeout=10)==0
 (out/'gui_smoke.json').write_text(json.dumps({'result':'PASS','exe':str(exe),'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'startup':True,'navigation_clicks':6,'clean_exit':True,'serial_commands':0},indent=2))
 print('PASS GUI startup, navigation, clean exit')
finally:
 if p.poll() is None:p.terminate();p.wait(timeout=5)
